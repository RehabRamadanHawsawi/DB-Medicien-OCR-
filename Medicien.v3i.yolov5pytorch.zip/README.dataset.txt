# Medicien > 2023-06-01 12:09pm
https://universe.roboflow.com/uqu-ndbf1/medicien

Provided by a Roboflow user
License: CC BY 4.0

